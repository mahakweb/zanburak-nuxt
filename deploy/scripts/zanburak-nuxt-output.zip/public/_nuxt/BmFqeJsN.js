function e(e=`FORM_STEPS`){let t=e,n=e=>e[t]||e.FORM_STEPS||[];return{data(){return{currentStep:0}},computed:{currentStepId(){let e=n(this);return e[this.currentStep]?.id||e[0]?.id||``},footerStepLabel(){let e=n(this),t=e[this.currentStep];return t?`${t.label} (${this.currentStep+1}/${e.length})`:``}},methods:{goToStep(e){let t=n(this);if(e>=0&&e<t.length){if(e>this.currentStep&&!this.validateFormStep(this.currentStep))return;this.currentStep=e}},nextStep(){if(!this.validateFormStep(this.currentStep))return;let e=n(this);this.currentStep<e.length-1&&(this.currentStep+=1)},prevStep(){this.currentStep>0&&--this.currentStep},validateFormStep(e){return!0}}}}var t=`flex shrink-0 group h-9 select-none rounded-lg bg-white px-3 text-sm font-semibold leading-8 text-gray-800 shadow-[0_-3px_0_0px_#d4d4d5_inset,0_0_0_1px_#f4f4f8_inset,0_0.5px_0_1.5px_#fff_inset] hover:bg-zinc-100 dark:bg-gray-900 dark:text-gray-100 dark:shadow-none dark:border dark:border-gray-700 dark:hover:bg-gray-800`,n=`
.form-input {
    display: block;
    width: 100%;
    padding: 0.625rem 0.75rem;
    font-size: 0.875rem;
    border-radius: 0.75rem;
    outline: none;
    background: #f3f4f6;
    color: #111827;
    border: 1px solid transparent;
    transition: box-shadow 0.15s, border-color 0.15s;
}
.form-input:focus {
    box-shadow: 0 0 0 2px #facc15;
}
.dark .form-input {
    background: #374151;
    color: #fff;
}
.field-label {
    display: block;
    font-size: 0.75rem;
    font-weight: 500;
    color: #6b7280;
    margin-bottom: 0.375rem;
}
.dark .field-label { color: #9ca3af; }
@media (min-width: 1024px) {
    .admin-form-layout {
        grid-template-columns: 14rem minmax(0, 1fr);
    }
}
`;export{t as n,e as r,n as t};