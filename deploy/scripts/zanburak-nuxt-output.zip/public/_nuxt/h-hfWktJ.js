import{G as e,H as t,J as n,K as r,Kt as i,T as a,Yt as o,d as s,f as c,j as l,m as u,ot as d,p as f,q as p,qt as m,r as h}from"./BkrIyEXs.js";import{at as g,ot as _,rt as v}from"./DpM1u6Ey.js";var y=typeof globalThis<`u`?globalThis:typeof window<`u`?window:typeof global<`u`?global:typeof self<`u`?self:{};function b(e,t,n){return n={path:t,exports:{},require:function(e,t){return x(e,t??n.path)}},e(n,n.exports),n.exports}function x(){throw Error(`Dynamic requires are not currently supported by @rollup/plugin-commonjs`)}var S=b(function(e,t){(function(t,n){e.exports=n()})(y,function(){var e=`__v-click-outside`,t=typeof window<`u`,n=typeof navigator<`u`,r=t&&(`ontouchstart`in window||n&&navigator.msMaxTouchPoints>0)?[`touchstart`]:[`click`],i=function(e){var t=e.event,n=e.handler;(0,e.middleware)(t)&&n(t)},a=function(t,n){var a=function(e){var t=typeof e==`function`;if(!t&&typeof e!=`object`)throw Error(`v-click-outside: Binding value must be a function or an object`);return{handler:t?e:e.handler,middleware:e.middleware||function(e){return e},events:e.events||r,isActive:!1!==e.isActive,detectIframe:!1!==e.detectIframe,capture:!!e.capture}}(n.value),o=a.handler,s=a.middleware,c=a.detectIframe,l=a.capture;if(a.isActive){if(t[e]=a.events.map(function(e){return{event:e,srcTarget:document.documentElement,handler:function(e){return function(e){var t=e.el,n=e.event,r=e.handler,a=e.middleware,o=n.path||n.composedPath&&n.composedPath();(o?o.indexOf(t)<0:!t.contains(n.target))&&i({event:n,handler:r,middleware:a})}({el:t,event:e,handler:o,middleware:s})},capture:l}}),c){var u={event:`blur`,srcTarget:window,handler:function(e){return function(e){var t=e.el,n=e.event,r=e.handler,a=e.middleware;setTimeout(function(){var e=document.activeElement;e&&e.tagName===`IFRAME`&&!t.contains(e)&&i({event:n,handler:r,middleware:a})},0)}({el:t,event:e,handler:o,middleware:s})},capture:l};t[e]=[].concat(t[e],[u])}t[e].forEach(function(n){var r=n.event,i=n.srcTarget,a=n.handler;return setTimeout(function(){t[e]&&i.addEventListener(r,a,l)},0)})}},o=function(t){(t[e]||[]).forEach(function(e){return e.srcTarget.removeEventListener(e.event,e.handler,e.capture)}),delete t[e]},s=t?{beforeMount:a,updated:function(e,t){var n=t.value,r=t.oldValue;JSON.stringify(n)!==JSON.stringify(r)&&(o(e),a(e,{value:n}))},unmounted:o}:{};return{install:function(e){e.directive(`click-outside`,s)},directive:s}})}),C={class:`v3ti-loader-wrapper`},w=[s(`div`,{class:`v3ti-loader`},null,-1),s(`span`,null,`Loading`,-1)];function T(e,n){return t(),u(`div`,C,w)}function E(e,t){t===void 0&&(t={});var n=t.insertAt;if(e&&typeof document<`u`){var r=document.head||document.getElementsByTagName(`head`)[0],i=document.createElement(`style`);i.type=`text/css`,n===`top`&&r.firstChild?r.insertBefore(i,r.firstChild):r.appendChild(i),i.styleSheet?i.styleSheet.cssText=e:i.appendChild(document.createTextNode(e))}}E(`.v3ti-loader-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #112B3C;
}
.v3ti-loader-wrapper .v3ti-loader {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  display: inline-block;
  border-top: 2px solid #112B3C;
  border-right: 2px solid transparent;
  box-sizing: border-box;
  animation: rotation 0.8s linear infinite;
  margin-right: 8px;
}
@keyframes rotation {
0% {
    transform: rotate(0deg);
}
100% {
    transform: rotate(360deg);
}
}`);var D={};D.render=T;var O={name:`Vue3TagsInput`,emits:[`update:modelValue`,`update:tags`,`on-limit`,`on-tags-changed`,`on-remove`,`on-error`,`on-focus`,`on-blur`,`on-select`,`on-select-duplicate-tag`,`on-new-tag`],props:{readOnly:{type:Boolean,default:!1},modelValue:{type:String,default:``},validate:{type:[String,Function,Object],default:``},addTagOnKeys:{type:Array,default:function(){return[13,`,`,32]}},placeholder:{type:String,default:``},tags:{type:Array,default:()=>[]},loading:{type:Boolean,default:!1},limit:{type:Number,default:-1},allowDuplicates:{type:Boolean,default:!1},addTagOnBlur:{type:Boolean,default:!1},selectItems:{type:Array,default:()=>[]},select:{type:Boolean,default:!1},duplicateSelectItem:{type:Boolean,default:!0},uniqueSelectField:{type:String,default:`id`},addTagOnKeysWhenSelect:{type:Boolean,default:!1},isShowNoData:{type:Boolean,default:!0}},components:{Loading:D},directives:{clickOutside:S.directive},data(){return{isInputActive:!1,isError:!1,newTag:``,innerTags:[],multiple:!1}},computed:{isLimit(){let e=this.limit>0&&Number(this.limit)===this.innerTags.length;return e&&this.$emit(`on-limit`),e},selectedItemsIds(){return this.duplicateSelectItem?[]:this.tags.map(e=>e[this.uniqueSelectField]||``)}},watch:{error(){this.isError=this.error},modelValue:{immediate:!0,handler(e){this.newTag=e}},tags:{deep:!0,immediate:!0,handler(e){this.innerTags=[...e]}}},methods:{isShot(e){return!!this.$slots[e]},makeItNormal(e){this.$emit(`update:modelValue`,e.target.value),this.$refs.inputTag.className=`v3ti-new-tag`,this.$refs.inputTag.style.textDecoration=`none`},resetData(){this.innerTags=[]},resetInputValue(){this.newTag=``,this.$emit(`update:modelValue`,``)},setPosition(){let e=this.$refs.inputBox,t=this.$refs.contextMenu;if(e&&t){t.style.display=`block`;let n=e.clientHeight||32;t.style.top=n+3+`px`}},closeContextMenu(){this.$refs.contextMenu&&(this.$refs.contextMenu.style={display:`none`})},handleSelect(e){if(this.isShowCheckmark(e)){let t=this.tags.filter(t=>e.id!==t.id);this.$emit(`update:tags`,t),this.$emit(`on-select-duplicate-tag`,e),this.resetInputValue()}else this.$emit(`on-select`,e);this.$nextTick(()=>{this.closeContextMenu()})},isShowCheckmark(e){return!this.duplicateSelectItem&&this.selectedItemsIds.includes(e[this.uniqueSelectField])},focusNewTag(){this.select&&!this.disabled&&this.setPosition(),!this.readOnly&&this.$el.querySelector(`.v3ti-new-tag`)&&this.$el.querySelector(`.v3ti-new-tag`).focus()},handleInputFocus(e){this.isInputActive=!0,this.$emit(`on-focus`,e)},handleInputBlur(e){this.isInputActive=!1,this.addNew(e),this.$emit(`on-blur`,e)},addNew(e){if(this.select&&!this.addTagOnKeysWhenSelect)return;let t=!e||this.addTagOnKeys.indexOf(e.keyCode)!==-1||this.addTagOnKeys.indexOf(e.key)!==-1,n=e&&e.type!==`blur`;(t||!n&&this.addTagOnBlur)&&!this.isLimit&&(this.newTag&&(this.allowDuplicates||this.innerTags.indexOf(this.newTag)===-1)&&this.validateIfNeeded(this.newTag)?(this.innerTags.push(this.newTag),this.addTagOnKeysWhenSelect&&(this.$emit(`on-new-tag`,this.newTag),this.updatePositionContextMenu()),this.resetInputValue(),this.tagChange(),e&&e.preventDefault()):(this.validateIfNeeded(this.newTag)?this.makeItError(!0):this.makeItError(!1),e&&e.preventDefault()))},updatePositionContextMenu(){this.$nextTick(()=>{this.setPosition()})},makeItError(e){this.newTag!==``&&(this.$refs.inputTag.className=`v3ti-new-tag v3ti-new-tag--error`,this.$refs.inputTag.style.textDecoration=`underline`,this.$emit(`on-error`,e))},validateIfNeeded(e){return this.validate===``||this.validate===void 0||typeof this.validate!=`function`||this.validate(e)},removeLastTag(){this.newTag||(this.innerTags.pop(),this.tagChange(),this.updatePositionContextMenu())},remove(e){this.innerTags.splice(e,1),this.tagChange(),this.$emit(`on-remove`,e),this.updatePositionContextMenu()},tagChange(){this.$emit(`on-tags-changed`,this.innerTags)}}},k={key:1,class:`v3ti-tag-content`},A=[`onClick`],j=[`placeholder`,`disabled`],M={key:0,class:`v3ti-loading`},N={key:1,class:`v3ti-no-data`},P={key:1},F={key:2},I=[`onClick`],L={class:`v3ti-context-item--label`},R={key:0,class:`v3ti-icon-selected-tag`,width:`44`,height:`44`,viewBox:`0 0 24 24`,"stroke-width":`1.5`,fill:`none`,"stroke-linecap":`round`,"stroke-linejoin":`round`},z=[s(`path`,{stroke:`none`,d:`M0 0h24v24H0z`},null,-1),s(`path`,{d:`M5 12l5 5l10 -10`},null,-1)];function B(y,b,x,S,C,w){let T=p(`Loading`),E=n(`click-outside`);return d((t(),u(`div`,{onClick:b[6]||=e=>w.focusNewTag(),class:i([{"v3ti--focus":C.isInputActive,"v3ti--error":C.isError},`v3ti`])},[s(`div`,{class:i([`v3ti-content`,{"v3ti-content--select":x.select}]),ref:`inputBox`},[(t(!0),u(h,null,e(C.innerTags,(e,n)=>(t(),u(`span`,{key:n,class:`v3ti-tag`},[w.isShot(`item`)?r(y.$slots,`item`,m(l({key:0},{name:e,index:n,tag:e}))):(t(),u(`span`,k,o(e),1)),x.readOnly?f(``,!0):(t(),u(`a`,{key:2,onClick:_(e=>w.remove(n),[`prevent`,`stop`]),class:`v3ti-remove-tag`},null,8,A))]))),128)),d(s(`input`,{ref:`inputTag`,placeholder:x.placeholder,"onUpdate:modelValue":b[0]||=e=>C.newTag=e,onKeydown:[b[1]||=g(_(function(){return w.removeLastTag&&w.removeLastTag(...arguments)},[`stop`]),[`delete`]),b[2]||=function(){return w.addNew&&w.addNew(...arguments)}],onBlur:b[3]||=function(){return w.handleInputBlur&&w.handleInputBlur(...arguments)},onFocus:b[4]||=function(){return w.handleInputFocus&&w.handleInputFocus(...arguments)},onInput:b[5]||=function(){return w.makeItNormal&&w.makeItNormal(...arguments)},class:`v3ti-new-tag`,disabled:x.readOnly},null,40,j),[[v,C.newTag]])],2),x.select?(t(),u(`section`,{key:0,class:i([`v3ti-context-menu`,{"v3ti-context-menu-no-data":!x.isShowNoData&&x.selectItems.length===0}]),ref:`contextMenu`},[x.loading?(t(),u(`div`,M,[w.isShot(`loading`)?r(y.$slots,`default`,{key:0}):(t(),c(T,{key:1}))])):f(``,!0),!x.loading&&x.selectItems.length===0&&x.isShowNoData?(t(),u(`div`,N,[w.isShot(`no-data`)?r(y.$slots,`no-data`,{key:0}):(t(),u(`span`,P,` No data `))])):f(``,!0),!x.loading&&x.selectItems.length>0?(t(),u(`div`,F,[(t(!0),u(h,null,e(x.selectItems,(e,n)=>(t(),u(`div`,{key:n,class:i([`v3ti-context-item`,{"v3ti-context-item--active":w.isShowCheckmark(e)}]),onClick:_(t=>w.handleSelect(e,n),[`stop`])},[s(`div`,L,[r(y.$slots,`select-item`,m(a(e)))]),w.isShowCheckmark(e)?(t(),u(`svg`,R,z)):f(``,!0)],10,I))),128))])):f(``,!0)],2)):f(``,!0)],2)),[[E,w.closeContextMenu]])}E(`.v3ti {
  border-radius: 5px;
  min-height: 32px;
  line-height: 1.4;
  background-color: #fff;
  border: 1px solid #9ca3af;
  cursor: text;
  text-align: left;
  -webkit-appearance: textfield;
  display: flex;
  flex-wrap: wrap;
  position: relative;
}
.v3ti .v3ti-icon-selected-tag {
  stroke: #19be6b;
  width: 1rem;
  height: 1rem;
  margin-left: 4px;
}
.v3ti--focus {
  outline: 0;
  border-color: #000000;
  box-shadow: 0 0 0 1px #000000;
}
.v3ti--error {
  border-color: #F56C6C;
}
.v3ti .v3ti-no-data {
  color: #d8d8d8;
  text-align: center;
  padding: 4px 7px;
}
.v3ti .v3ti-loading {
  padding: 4px 7px;
  text-align: center;
}
.v3ti .v3ti-context-menu {
  max-height: 150px;
  min-width: 150px;
  overflow: auto;
  display: none;
  outline: none;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  margin: 0;
  padding: 5px 0;
  background: #ffffff;
  z-index: 1050;
  color: #475569;
  box-shadow: 0 3px 8px 2px rgba(0, 0, 0, 0.1);
  border-radius: 0 0 6px 6px;
}
.v3ti .v3ti-context-menu .v3ti-context-item {
  padding: 4px 7px;
  display: flex;
  align-items: center;
}
.v3ti .v3ti-context-menu .v3ti-context-item:hover {
  background: #e8e8e8;
  cursor: pointer;
}
.v3ti .v3ti-context-menu .v3ti-context-item--label {
  flex: 1;
  min-width: 1px;
}
.v3ti .v3ti-context-menu .v3ti-context-item--active {
  color: #317CAF;
}
.v3ti .v3ti-context-menu-no-data {
  padding: 0;
}
.v3ti .v3ti-content {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
}
.v3ti .v3ti-content--select {
  padding-right: 30px;
}
.v3ti .v3ti-tag {
  display: flex;
  font-weight: 400;
  margin: 3px;
  padding: 0 5px;
  background: #317CAF;
  color: #ffffff;
  height: 27px;
  border-radius: 5px;
  align-items: center;
  max-width: calc(100% - 16px);
}
.v3ti .v3ti-tag .v3ti-tag-content {
  flex: 1;
  min-width: 1px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.v3ti .v3ti-tag .v3ti-remove-tag {
  color: #ffffff;
  transition: opacity 0.3s ease;
  opacity: 0.5;
  cursor: pointer;
  padding: 0 5px 0 7px;
}
.v3ti .v3ti-tag .v3ti-remove-tag::before {
  content: "x";
}
.v3ti .v3ti-tag .v3ti-remove-tag:hover {
  opacity: 1;
}
.v3ti .v3ti-new-tag {
  background: transparent;
  border: 0;
  font-weight: 400;
  margin: 3px;
  outline: none;
  padding: 0 4px;
  flex: 1;
  min-width: 60px;
  height: 27px;
}
.v3ti .v3ti-new-tag--error {
  color: #F56C6C;
}`),O.render=B;var V=(()=>{let e=O;return e.install=t=>{t.component(`Vue3TagsInput`,e)},e})();export{V as t};